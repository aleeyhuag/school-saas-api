<?php

use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

it('rejects a student update with a class from another school', function () {
    $schoolA = \App\Models\School::factory()->create();
    $schoolB = \App\Models\School::factory()->create();
    $user = \App\Models\User::factory()->create(['school_id' => $schoolA->id]);
    $user->assignRole('principal');

    $classA = \App\Models\SchoolClass::create(['school_id'=>$schoolA->id,'name'=>'JSS 1']);
    $classB = \App\Models\SchoolClass::create(['school_id'=>$schoolB->id,'name'=>'JSS 1']);

    $student = \App\Models\Student::create([
        'school_id'=>$schoolA->id,'school_class_id'=>$classA->id,
        'admission_number'=>'A-001','first_name'=>'A','last_name'=>'Student','status'=>'active',
    ]);

    $this->actingAs($user,'sanctum')
        ->putJson("/api/students/{$student->id}", [
            'school_class_id'=>$classB->id,'admission_number'=>'A-001',
            'first_name'=>'A','last_name'=>'Student',
        ])->assertStatus(422);
});

it('rejects a score when the student belongs to a different class', function () {
    $school = \App\Models\School::factory()->create();
    $user = \App\Models\User::factory()->create(['school_id'=>$school->id]);
    $user->assignRole('principal');

    $classA = \App\Models\SchoolClass::create(['school_id'=>$school->id,'name'=>'JSS 1']);
    $classB = \App\Models\SchoolClass::create(['school_id'=>$school->id,'name'=>'JSS 2']);
    $subject = \App\Models\Subject::create(['school_id'=>$school->id,'name'=>'Maths']);
    $classA->subjects()->attach($subject->id);
    $session = \App\Models\AcademicSession::factory()->create(['school_id'=>$school->id]);
    $term = \App\Models\Term::create([
        'school_id'=>$school->id,'academic_session_id'=>$session->id,'name'=>'First Term',
        'start_date'=>now(),'end_date'=>now()->addMonths(3),'is_current'=>true,
    ]);
    $student = \App\Models\Student::create([
        'school_id'=>$school->id,'school_class_id'=>$classB->id,
        'admission_number'=>'B-001','first_name'=>'B','last_name'=>'Student','status'=>'active',
    ]);

    $this->actingAs($user,'sanctum')->postJson('/api/subject-scores', [
        'term_id'=>$term->id,'school_class_id'=>$classA->id,'subject_id'=>$subject->id,
        'student_id'=>$student->id,'ca_score'=>10,'ca_max'=>20,
    ])->assertStatus(422);
});

it('lets a class teacher read their own class scores without subject assignment', function () {
    $school = \App\Models\School::factory()->create();
    $teacher = \App\Models\User::factory()->create(['school_id'=>$school->id]);
    $teacher->assignRole('teacher');
    $class = \App\Models\SchoolClass::create(['school_id'=>$school->id,'name'=>'JSS 1']);
    $subject = \App\Models\Subject::create(['school_id'=>$school->id,'name'=>'Maths']);
    $class->subjects()->attach($subject->id);
    $session = \App\Models\AcademicSession::factory()->create(['school_id'=>$school->id]);
    $term = \App\Models\Term::create([
        'school_id'=>$school->id,'academic_session_id'=>$session->id,'name'=>'First Term',
        'start_date'=>now(),'end_date'=>now()->addMonths(3),'is_current'=>true,
    ]);
    $student = \App\Models\Student::create([
        'school_id'=>$school->id,'school_class_id'=>$class->id,
        'admission_number'=>'C-001','first_name'=>'C','last_name'=>'Student','status'=>'active',
    ]);
    \App\Models\TeacherAssignment::create([
        'school_id'=>$school->id,'user_id'=>$teacher->id,'school_class_id'=>$class->id,
        'subject_id'=>null,'is_class_teacher'=>true,
    ]);
    \App\Models\SubjectScore::create([
        'school_id'=>$school->id,'term_id'=>$term->id,'school_class_id'=>$class->id,
        'subject_id'=>$subject->id,'student_id'=>$student->id,'ca_score'=>10,'ca_max'=>20,
    ]);

    $this->actingAs($teacher,'sanctum')
        ->getJson("/api/subject-scores?school_class_id={$class->id}&subject_id={$subject->id}&term_id={$term->id}")
        ->assertOk()->assertJsonCount(1);
});
